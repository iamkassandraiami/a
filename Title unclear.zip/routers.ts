import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import Stripe from "stripe";
import { conversationRouter, taskRouter, integrationRouter, agentConfigRouter, workflowRouter } from "./agents/persistence-routers";
import { protonEmailRouter } from "./integrations/proton-email";
import { smsForwardingRouter } from "./integrations/sms-forwarding";
import { accountCreatorRouter } from "./agents/account-creator";
import { salesBlitzExecutorRouter } from "./agents/sales-blitz-executor";

const stripeKey = process.env.STRIPE_SECRET_KEY;
const stripe = stripeKey ? new Stripe(stripeKey) : null;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============================================================================
  // PRODUCTS ROUTER
  // ============================================================================
  products: router({
    list: publicProcedure.query(async () => {
      return db.getAllProducts();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return db.getProductBySlug(input.slug);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getProductById(input.id);
      }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return db.getProductsByCategory(input.category);
      }),
  }),

  // ============================================================================
  // BUNDLES ROUTER
  // ============================================================================
  bundles: router({
    list: publicProcedure.query(async () => {
      return db.getAllBundles();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return db.getBundleBySlug(input.slug);
      }),
  }),

  // ============================================================================
  // CHECKOUT ROUTER
  // ============================================================================
  checkout: router({
    createSession: publicProcedure
      .input(
        z.object({
          productIds: z.array(z.number()).optional(),
          bundleId: z.number().optional(),
          successUrl: z.string(),
          cancelUrl: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [];

          // Add products to line items
          if (input.productIds && input.productIds.length > 0) {
            for (const productId of input.productIds) {
              const product = await db.getProductById(productId);
              if (product) {
                lineItems.push({
                  price_data: {
                    currency: "usd",
                    product_data: {
                      name: product.name,
                      description: product.description || undefined,
                      images: product.image ? [product.image] : undefined,
                    },
                    unit_amount: Math.round(parseFloat(product.price.toString()) * 100),
                  },
                  quantity: 1,
                });
              }
            }
          }

          // Add bundle to line items
          if (input.bundleId) {
            const bundle = await db.getBundleBySlug("");
            if (bundle) {
              lineItems.push({
                price_data: {
                  currency: "usd",
                  product_data: {
                    name: bundle.name,
                    description: bundle.description || undefined,
                  },
                  unit_amount: Math.round(parseFloat(bundle.price.toString()) * 100),
                },
                quantity: 1,
              });
            }
          }

          if (lineItems.length === 0) {
            throw new Error("No products or bundles selected");
          }

          if (!stripe) {
            throw new Error("Stripe is not configured");
          }

          const sessionParams: any = {
            line_items: lineItems,
            mode: "payment",
            success_url: input.successUrl,
            cancel_url: input.cancelUrl,
            metadata: {
              userId: ctx.user?.id.toString() || "guest",
              productIds: input.productIds?.join(",") || "",
              bundleId: input.bundleId?.toString() || "",
            },
          };

          if (ctx.user?.email) {
            sessionParams.customer_email = ctx.user.email;
          }