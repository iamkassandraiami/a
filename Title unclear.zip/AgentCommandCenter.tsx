 * Agent Command Center - Natural language chat interface for communicating with agents
 */

import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, Zap, BarChart3, Users, Settings } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";

interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "agent";
  agentRole?: string;
  content: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

interface AgentStatus {
  role: string;
  status: "idle" | "working" | "waiting" | "error" | "offline";
  lastActive: Date;
  tasksCompleted: number;
  tasksFailed: number;
}

export default function AgentCommandCenter() {
  const [, setLocation] = useLocation();
  const { data: user, isLoading: userLoading } = trpc.auth.me.useQuery();

  // Initialize state hooks BEFORE any conditional returns
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-1",
      role: "assistant",
      content:
        "Welcome to the Vibe Coding Command Center! I'm your Management Agent. I coordinate all specialized agents and handle your requests. You can communicate with me in natural English, and I'll route your commands to the appropriate agents.\n\n**Available Agents:**\n- **Trend Predictor**: Monitors social media and identifies viral opportunities\n- **Content Creator**: Generates marketing materials and content\n- **Sales Agent**: Handles lead generation and outreach\n- **Operations Agent**: Manages workflows and automation\n- **Strategy Agent**: Provides business intelligence and planning\n- **Advanced Coder**: Maintains platform and configures models\n- **Platform Architect**: Manages integrations and customizations\n\n**Try saying things like:**\n- \"Generate a blog post about AI automation\"\n- \"What are the current trends?\"\n- \"Identify high-quality leads\"\n- \"Optimize our sales pipeline\"\n- \"Create a new automation workflow\"",
      timestamp: new Date(),
    },
  ]);

  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [agentStatuses, setAgentStatuses] = useState<AgentStatus[]>([